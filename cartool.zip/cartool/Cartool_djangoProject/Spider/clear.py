import json
import csv

data = []
with open('动漫信息.json', 'r', encoding='utf-8') as json_file:
    for line in json_file:
        item = json.loads(line)
        data.append(item)

# 将列表中的逗号替换为顿号
for item in data:
    if "声优" in item:
        item["声优"] = "、".join(item["声优"])

# 写入 CSV 文件
with open('new_data.csv', 'w', newline='', encoding='utf-8') as csv_file:
    writer = csv.DictWriter(csv_file, fieldnames=data[0].keys())
    writer.writeheader()
    writer.writerows(data)
