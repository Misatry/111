﻿$(function () {
    part1();
    part2();
    part3();
    part4();
    part5();
    part6();

    function part1() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('part1'));
        // 向 Flask 后台发送 GET 请求
        fetch('/api/part1')  //
            .then(response => response.json())  // 解析 JSON 响应
            .then(data => {
                // 更新图表的数据
                option = {
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'shadow',
                            shadowStyle: {
                                color: 'rgba(255, 255, 255, 0.1)' // 设置阴影颜色
                            }
                        }
                    },

                    grid: {
                        left: '10%', // 调整左侧距离
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis: {
                        type: 'value',
                        boundaryGap: [0, 0.01],
                        axisLabel: {
                            color: '#FFFFFF', // 将X轴标签字体颜色改为白色
                            fontSize: 12 // 设置字体大小
                        },
                        splitLine: {
                            show: false // 隐藏X轴的分割线
                        },
                        axisLine: {
                            lineStyle: {
                                color: 'rgba(255, 255, 255, 0.5)' // 设置X轴线的颜色
                            }
                        }
                    },
                    yAxis: {
                        type: 'category',
                        data: data.nameList,
                        axisLabel: {
                            color: '#FFFFFF', // 将Y轴标签字体颜色改为白色
                            fontSize: 12, // 设置字体大小
                            formatter: function (value) {
                                if (value.length > 3) {
                                    return value.substring(0, 3) + '..'; // 显示前三个字后加..
                                } else {
                                    return value;
                                }
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: 'rgba(255, 255, 255, 0.5)' // 设置Y轴线的颜色
                            }
                        }
                    },
                    series: [
                        {
                            name: '销量',
                            type: 'bar',
                            data: data.valueList,
                            barWidth: '60%', // 设置柱子的宽度，间接调整间距
                            itemStyle: {
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 1,
                                    y2: 0,
                                    colorStops: [
                                        {offset: 0, color: '#F39C12'}, // 柱子顶部颜色，渐变的橙色
                                        {offset: 1, color: '#E67E22'} // 柱子底部颜色，渐变的深橙色
                                    ]
                                },
                                barBorderRadius: [0, 10, 10, 0], // 将柱子形状改为圆角
                                shadowColor: 'rgba(0, 0, 0, 0.3)', // 设置阴影颜色
                                shadowBlur: 10 // 设置阴影模糊度
                            },
                            label: {
                                show: true,
                                position: 'right',
                                color: '#FFFFFF', // 将柱子上的标签字体颜色改为白色
                                fontSize: 12 // 设置字体大小
                            }
                        }
                    ]
                };

                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            })
            .catch(error => console.error('Error fetching data:', error));

        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }

    function part2() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('part2'));
        // 向 Flask 后台发送 GET 请求
        fetch('/api/part2')  //
            .then(response => response.json())  // 解析 JSON 响应
            .then(data => {
                // 更新图表的数据
                var option = {
                    xAxis: {
                        type: 'category',
                        data: data.date_list,
                        axisLabel: {
                            color: '#fff' // 将 X 轴标签字体颜色改为白色
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#fff' // 将 X 轴线颜色改为白色
                            }
                        }
                    },
                    yAxis: {
                        type: 'value',
                        axisLabel: {
                            color: '#fff' // 将 Y 轴标签字体颜色改为白色
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#fff' // 将 Y 轴线颜色改为白色
                            }
                        }
                    },
                    tooltip: {
                        trigger: 'axis',
                        formatter: function (params) {
                            var date = params[0].name;
                            var name = data.name_list[params[0].dataIndex];
                            var sales = params[0].value;
                            return `日期: ${date}<br>名称: ${name}<br>销量: ${sales}`;
                        },
                        backgroundColor: 'rgba(0, 0, 0, 0.7)', // 提示框背景颜色
                        textStyle: {
                            color: '#fff' // 提示框文字颜色
                        }
                    },
                    series: [
                        {
                            data: data.sales_list,
                            type: 'line',
                            smooth: true,
                            lineStyle: {
                                width: 3, // 折线粗细
                                color: '#ff7f50' // 折线颜色
                            },
                            itemStyle: {
                                color: '#ff7f50' // 折线点颜色
                            }
                        }
                    ]
                };

                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            })
            .catch(error => console.error('Error fetching data:', error));

        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }

    function part3() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('part3'));
        // 向 Flask 后台发送 GET 请求
        fetch('/api/part3')  //
            .then(response => response.json())  // 解析 JSON 响应
            .then(data => {
                // 更新图表的数据
                option = {
                    tooltip: {
                        trigger: 'axis'
                    },
                    legend: {
                        data: ['最高价格', '最低价格'],
                        textStyle: {
                            color: '#FFFFFF' // 图例字体颜色改为白色
                        }
                    },
                    toolbox: {
                        show: true,
                        feature: {
                            dataView: {show: true, readOnly: false},
                            magicType: {show: true, type: ['line', 'bar']},
                            restore: {show: true},
                            saveAsImage: {show: true}
                        }
                    },
                    calculable: true,
                    xAxis: [
                        {
                            type: 'category',
                            data: data.nameList,
                            axisLabel: {
                                color: '#FFFFFF', // X 轴标签字体颜色改为白色
                                fontSize: 12,
                                fontWeight: 'bold'
                            },
                            axisLine: {
                                lineStyle: {
                                    color: '#ccc' // X 轴线颜色
                                }
                            },
                            axisTick: {
                                show: false // 隐藏 X 轴刻度线
                            }
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value',
                            axisLabel: {
                                color: '#FFFFFF', // Y 轴标签字体颜色改为白色
                                fontSize: 12,
                                fontWeight: 'bold'
                            },
                            axisLine: {
                                lineStyle: {
                                    color: '#ccc' // Y 轴线颜色
                                }
                            },
                            axisTick: {
                                show: false // 隐藏 Y 轴刻度线
                            },
                            splitLine: {
                                lineStyle: {
                                    color: ['#eee'], // Y 轴分割线颜色
                                    type: 'dashed'  // Y 轴分割线样式为虚线
                                }
                            }
                        }
                    ],
                    series: [
                        {
                            name: '最高价格',
                            type: 'bar',
                            data: data.max_list,
                            itemStyle: {
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 0,
                                    y2: 1,
                                    colorStops: [{
                                        offset: 0, color: '#FF6384' // 柱子渐变色开始
                                    }, {
                                        offset: 1, color: '#FFA500' // 柱子渐变色结束
                                    }]
                                },
                                barBorderRadius: [10, 10, 0, 0] // 柱子顶部圆角
                            },
                            markLine: {
                                data: [{type: 'average', name: 'Avg'}]
                            }
                        },
                        {
                            name: '最低价格',
                            type: 'bar',
                            data: data.min_list,
                            itemStyle: {
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 0,
                                    y2: 1,
                                    colorStops: [{
                                        offset: 0, color: '#36A2EB' // 柱子渐变色开始
                                    }, {
                                        offset: 1, color: '#4BC0C0' // 柱子渐变色结束
                                    }]
                                },
                                barBorderRadius: [10, 10, 0, 0] // 柱子顶部圆角
                            },
                            markLine: {
                                data: [{type: 'average', name: 'Avg'}]
                            }
                        }
                    ],
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    }
                };

                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            })
            .catch(error => console.error('Error fetching data:', error));

        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }

    function part4() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('part4'));
        // 向 Flask 后台发送 GET 请求
        fetch('/api/part4')  //
            .then(response => response.json())  // 解析 JSON 响应
            .then(data => {
                // 更新图表的数据
                option = {
                    xAxis: {
                        type: 'category',
                        boundaryGap: false,
                        data: data.date_list,
                        axisLabel: {
                            color: '#FFFFFF', // X 轴标签字体颜色改为白色
                            fontSize: 12,  // X 轴标签字体大小
                            fontWeight: 'bold' // X 轴标签字体加粗
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#ccc' // X 轴线颜色
                            }
                        },
                        axisTick: {
                            show: false // 隐藏 X 轴刻度线
                        }
                    },
                    yAxis: {
                        type: 'value',
                        boundaryGap: [0, '30%'],
                        axisLabel: {
                            color: '#FFFFFF', // Y 轴标签字体颜色改为白色
                            fontSize: 12,  // Y 轴标签字体大小
                            fontWeight: 'bold' // Y 轴标签字体加粗
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#ccc' // Y 轴线颜色
                            }
                        },
                        axisTick: {
                            show: false // 隐藏 Y 轴刻度线
                        },
                        splitLine: {
                            lineStyle: {
                                color: ['#eee'], // Y 轴分割线颜色
                                type: 'dashed'  // Y 轴分割线样式为虚线
                            }
                        }
                    },
                    series: [
                        {
                            type: 'line',
                            smooth: 0.6, // 折线平滑度
                            symbol: 'none', // 去掉线上的小点点
                            lineStyle: {
                                color: '#83fc66', // 折线颜色
                                width: 5, // 折线粗细
                                shadowColor: 'rgba(0, 0, 0, 0.5)', // 折线阴影颜色
                                shadowBlur: 10, // 折线阴影模糊程度
                                shadowOffsetX: 0, // 折线阴影水平偏移
                                shadowOffsetY: 5 // 折线阴影垂直偏移
                            },
                            data: data.dataList, // 假设这是你的数据列表
                            areaStyle: {
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 0,
                                    y2: 1,
                                    colorStops: [{
                                        offset: 0, color: '#5470C6' // 渐变开始颜色
                                    }, {
                                        offset: 1, color: 'rgba(84, 112, 198, 0.2)' // 渐变结束颜色
                                    }]
                                }
                            }
                        }
                    ],
                    tooltip: {
                        trigger: 'axis', // 触发类型为 axis，即在坐标轴上触发
                        axisPointer: {
                            type: 'line', // 指示器类型为线
                            lineStyle: {
                                color: '#999', // 指示器线条颜色
                                width: 2, // 指示器线条宽度
                                type: 'solid' // 指示器线条样式为实线
                            }
                        },
                        formatter: function (params) {
                            // params 是一个数组，包含当前触发 tooltip 的数据信息
                            let date = params[0].axisValue; // 获取日期
                            let value = params[0].value; // 获取值
                            return `日期: ${date}<br/>数据: ${value}`;
                        }
                    }
                };

                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            })
            .catch(error => console.error('Error fetching data:', error));

        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }

    function part5() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('part5'));
        // 向 Flask 后台发送 GET 请求
        fetch('/api/part5')  //
            .then(response => response.json())  // 解析 JSON 响应
            .then(data => {
                // 更新图表的数据
                option = {
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'shadow'
                        }
                    },
                    grid: {
                        left: '3%',
                        right: '4%',
                        bottom: '3%',
                        containLabel: true
                    },
                    xAxis: [
                        {
                            type: 'category',
                            data: data.name_list,
                            axisTick: {
                                alignWithLabel: true
                            },
                            axisLabel: {
                                color: '#ffffff', // 字体颜色改为白色
                                fontSize: 12, // 字体大小
                                rotate: 20 // 旋转角度（可选）
                            },
                            axisLine: {
                                lineStyle: {
                                    color: '#ffffff' // 轴线颜色改为白色
                                }
                            }
                        }
                    ],
                    yAxis: [
                        {
                            type: 'value',
                            axisLabel: {
                                color: '#ffffff', // 字体颜色改为白色
                                fontSize: 14 // 字体大小
                            },
                            axisLine: {
                                lineStyle: {
                                    color: '#ffffff' // 轴线颜色改为白色
                                }
                            },
                            splitLine: {
                                lineStyle: {
                                    color: 'rgba(255, 255, 255, 0.3)' // 分割线颜色改为半透明白色
                                }
                            }
                        }
                    ],
                    series: [
                        {
                            name: '评论数',
                            type: 'bar',
                            barWidth: '60%',
                            data: data.value_list,
                            itemStyle: {
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 0,
                                    y2: 1,
                                    colorStops: [
                                        {offset: 0, color: '#83a7e0'}, // 柱子顶部颜色
                                        {offset: 1, color: '#2a5caa'}  // 柱子底部颜色
                                    ]
                                },
                                barBorderRadius: [5, 5, 0, 0], // 圆角处理（顶部圆角）
                                shadowColor: 'rgba(0, 0, 0, 0.3)', // 阴影颜色
                                shadowBlur: 10 // 阴影模糊大小
                            },
                            label: {
                                show: true,
                                position: 'top',
                                color: '#ffffff', // 标签字体颜色改为白色
                                fontSize: 14, // 标签字体大小
                                formatter: '{c}' // 仅显示数值
                            }
                        }
                    ]
                };

                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            })
            .catch(error => console.error('Error fetching data:', error));

        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }

    function part6() {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('part6'));
        // 向 Flask 后台发送 GET 请求
        fetch('/api/part6')  //
            .then(response => response.json())  // 解析 JSON 响应
            .then(data => {
                // 更新图表的数据
                option = {
                    tooltip: {
                        trigger: 'axis',
                        axisPointer: {
                            type: 'shadow'
                        }
                    },
                    yAxis: {
                        type: 'category',
                        data: data.name_list,
                        axisLabel: {
                            color: '#ffffff',
                            fontSize: 14,
                            formatter: function (value) {
                                if (value.length > 2) {
                                    return value.substring(0, 2) + '..';
                                }
                                return value;
                            }
                        },
                        axisLine: {
                            lineStyle: {
                                color: '#ffffff'
                            }
                        }
                    },
                    xAxis: {
                        type: 'value',
                        axisLabel: {
                            show: false, // 隐藏 x 轴的标签
                        },
                        axisLine: {
                            show: false, // 隐藏 x 轴的线
                            lineStyle: {
                                color: '#ffffff'
                            }
                        },
                        splitLine: {
                            lineStyle: {
                                color: 'rgba(255, 255, 255, 0.3)'
                            }
                        }
                    },
                    series: [
                        {
                            name: '总销售价格',
                            type: 'bar',
                            data: data.value_list,
                            itemStyle: {
                                color: {
                                    type: 'linear',
                                    x: 0,
                                    y: 0,
                                    x2: 1,
                                    y2: 0,
                                    colorStops: [
                                        {offset: 0, color: '#00c6ff'},  // 新的开始颜色
                                        {offset: 1, color: '#0072ff'}   // 新的结束颜色
                                    ]
                                },
                                barBorderRadius: [10, 10, 10, 10], // 两边都设置为圆角
                                shadowColor: 'rgba(0, 0, 0, 0.3)',
                                shadowBlur: 10
                            },
                            label: {
                                show: false, // 设置为 false 以去掉数字
                                position: 'right',
                                color: '#ffffff',
                                fontSize: 14,
                                formatter: '{c}'
                            }
                        }
                    ]
                };

                // 使用刚指定的配置项和数据显示图表。
                myChart.setOption(option);
            })
            .catch(error => console.error('Error fetching data:', error));

        window.addEventListener("resize", function () {
            myChart.resize();
        });
    }


})



		
		
		


		









