﻿
$(function () {
echarts_1();
echarts_2();
echarts_4();
echarts_31();

echarts_5();
echarts_6();
function echarts_1() {
        $.get('http://localhost:8088/getPart2', function (res) {
            // 基于准备好的dom，初始化echarts实例
            var myChart = echarts.init(document.getElementById('echart1'));

            option = {
                //  backgroundColor: '#00265f',
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                grid: {
                    left: '0%',
                    top: '10px',
                    right: '0%',
                    bottom: '4%',
                    containLabel: true
                },
                xAxis: [{
                    type: 'category',
                    data: res.key,
                    axisLine: {
                        show: true,
                        lineStyle: {
                            color: "rgba(255,255,255,.1)",
                            width: 1,
                            type: "solid"
                        },
                    },

                    axisTick: {
                        show: false,
                    },
                    axisLabel: {
                        // interval: 5,
                        // rotate:50,
                        show: true,
                        splitNumber: 15,
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize: '12',
                        },
                    },
                }],
                yAxis: [{
                    type: 'value',
                    axisLabel: {
                        //formatter: '{value} %'
                        show: true,
                        textStyle: {
                            color: "rgba(255,255,255,.6)",
                            fontSize: '12',
                        },
                    },
                    axisTick: {
                        show: false,
                    },
                    axisLine: {
                        show: true,
                        lineStyle: {
                            color: "rgba(255,255,255,.1	)",
                            width: 1,
                            type: "solid"
                        },
                    },
                    splitLine: {
                        lineStyle: {
                            color: "rgba(255,255,255,.1)",
                        }
                    }
                }],
                series: [
                    {
                        type: 'bar',
                        data:res.val,
                        barWidth: '35%', //柱子宽度
                        // barGap: 1, //柱子之间间距
                        itemStyle: {
                            normal: {
                                color: '#2f89cf',
                                opacity: 1,
                                barBorderRadius: 5,
                            }
                        }
                    }

                ]
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
            window.addEventListener("resize", function () {
                myChart.resize();
            });
        })
}
function echarts_2() {
    $.get('http://localhost:8088/getPart1', function (res) {
        // 基于准备好的dom，初始化echarts实例
        var myChart = echarts.init(document.getElementById('echart2'));

       option = {
  //  backgroundColor: '#00265f',
    tooltip: {
        trigger: 'axis',
        axisPointer: { type: 'shadow'}
    },
    grid: {
        left: '0%',
		top:'10px',
        right: '0%',
        bottom: '4%',
       containLabel: true
    },
    xAxis: [{
        type: 'category',
      		data: res.key,
        axisLine: {
            show: true,
         lineStyle: {
                color: "rgba(255,255,255,.1)",
                width: 1,
                type: "solid"
            },
        },
		
        axisTick: {
            show: false,
        },
		axisLabel:  {
                // interval: 5,
               // rotate:50,
                show: true,
                splitNumber: 15,
                textStyle: {
 					color: "rgba(255,255,255,.6)",
                    fontSize: '12',
                },
            },
    }],
    yAxis: [{
        type: 'value',
        axisLabel: {
           //formatter: '{value} %'
			show:true,
			 textStyle: {
 					color: "rgba(255,255,255,.6)",
                    fontSize: '12',
                },
        },
        axisTick: {
            show: false,
        },
        axisLine: {
            show: true,
            lineStyle: {
                color: "rgba(255,255,255,.1	)",
                width: 1,
                type: "solid"
            },
        },
        splitLine: {
            lineStyle: {
               color: "rgba(255,255,255,.1)",
            }
        }
    }],
    series: [
		{
       
        type: 'bar',
        data: res.val,
        barWidth:'35%', //柱子宽度
       // barGap: 1, //柱子之间间距
        itemStyle: {
            normal: {
                color:'#27d08a',
                opacity: 1,
				barBorderRadius: 5,
            }
        }
    }
		
	]
};
      
        // 使用刚指定的配置项和数据显示图表。
        myChart.setOption(option);
        window.addEventListener("resize",function(){
            myChart.resize();
        });})
    }
    function echarts_5() {
        $.get('http://localhost:8088/getPart5', function (res) {
            // 基于准备好的dom，初始化echarts实例
            var myChart = echarts.init(document.getElementById('echart5'));

            option = {
                tooltip: {
                    trigger: 'item'
                },
                series: [{
                    type: 'funnel',
                    left: '10%',
                    right: '10%',
                    top: '10%',
                    bottom: '10%',
                    width: '80%', // 漏斗图宽度
                    max: 100, // 漏斗的最大值
                    sort: 'descending', // 根据值降序排列
                    itemStyle: {
                        borderColor: '#fff',
                        borderWidth: 1,
                    },
                    label: {
                        show: true,
                        position: 'inside',
                        formatter: '{b}: {c}%', // 显示名称和数值
                        textStyle: {
                            color: '#fff' // 标签颜色
                        }
                    },
                    data: res.val.map((value, index) => ({
                        value: value,
                        name: res.key[index] // 假设 res.key 和 res.val 数组一一对应
                    }))
                }]
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
            window.addEventListener("resize", function () {
                myChart.resize();
            });
        });
    }

    function echarts_4() {
        $.get('http://localhost:8088/getPart3', function (res) {
            // 基于准备好的dom，初始化echarts实例
            var myChart = echarts.init(document.getElementById('echart4'));

            var option = {
                color: ['#FF5733', '#F1C40F', '#3498DB'], // 自定义每种柱子的颜色
                tooltip: {
                    trigger: 'axis',
                    axisPointer: {
                        type: 'shadow'
                    }
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    textStyle: {
                        color: '#000' // 将图例颜色设置为黑色或其他颜色
                    },

                },
                xAxis: {
                    type: 'category',
                    data: res.map(item => item.name), // 使用名称作为 x 轴的数据
                    axisLine: {
                        lineStyle: {
                            color: '#ccc' // x 轴线的颜色
                        }
                    }
                },
                yAxis: {
                    type: 'value',
                    name: '数量', // y 轴名称
                    axisLine: {
                        lineStyle: {
                            color: '#ccc' // y 轴线的颜色
                        }
                    },
                    splitLine: {
                        lineStyle: {
                            type: 'dashed' // y 轴划分线的样式
                        }
                    }
                },
                series: [{
                    name: '好评数',
                    type: 'bar',
                    data: res.map(item => item.value), // 假设 res 中每个对象都有 value 属性
                    itemStyle: {
                        color: '#FF5733', // 好评数柱子的颜色
                        borderColor: '#fff', // 柱子边框颜色
                        borderWidth: 1
                    }
                }, {
                    name: '差评数',
                    type: 'bar',
                    data: res.map(item => item.value1), // 假设 res 中每个对象都有 value1 属性
                    itemStyle: {
                        color: '#F1C40F', // 差评数柱子的颜色
                        borderColor: '#fff', // 柱子边框颜色
                        borderWidth: 1
                    }
                }, {
                    name: '中评数',
                    type: 'bar',
                    data: res.map(item => item.value2), // 假设 res 中每个对象都有 value2 属性
                    itemStyle: {
                        color: '#3498DB', // 中评数柱子的颜色
                        borderColor: '#fff', // 柱子边框颜色
                        borderWidth: 1
                    }
                }]
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);
            window.addEventListener("resize", function () {
                myChart.resize();
            });
        });
    }



    function echarts_6() {
        $.get('http://localhost:8088/getPart6', function (res) {
            // 基于准备好的dom，初始化echarts实例
            var myChart = echarts.init(document.getElementById('echart6'));

            option = {
                color: [
                    '#065aab', '#066eab', '#0682ab', '#0696ab',
                    '#06a0ab', '#06b4ab', '#06c8ab', '#06dcab', '#06f0ab'
                ],
                title: {
                    left: 'center',
                    top: 'top',
                    textStyle: {
                        fontSize: 20,
                        color: '#fff',
                        fontWeight: 'bold'
                    },
                    subtextStyle: {
                        color: '#ccc'
                    }
                },
                tooltip: {
                    trigger: 'item',
                    formatter: function (params) {
                        return `${params.name}: ${params.value} (${params.percent}%)`;
                    }
                },
                legend: {
                    orient: 'vertical',
                    left: 'left',
                    textStyle: {
                        color: '#fff'
                    }
                },
                series: [
                    {
                        name: '数量',
                        type: 'pie',
                        radius: '55%',
                        center: ['50%', '50%'],
                        data: res,
                        emphasis: {
                            itemStyle: {
                                shadowBlur: 10,
                                shadowOffsetX: 0,
                                shadowColor: 'rgba(255, 255, 255, 0.5)',
                            }
                        },
                        label: {
                            show: true,
                            position: 'outside', // 数据标签显示在外部
                            formatter: '{b}: {c} ({d}%)', // 显示名称，数值和百分比
                            textStyle: {
                                color: '#fff'
                            }
                        },
                        labelLine: {
                            show: true,
                            lineStyle: {
                                color: '#fff' // 数据标签连线颜色
                            }
                        }
                    }
                ]
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);

            // 处理窗口大小变化
            window.addEventListener("resize", function () {
                myChart.resize();
            });
        });
    }

    function echarts_31() {
        $.get('http://localhost:8088/getPart4', function (res) {
            // 基于准备好的dom，初始化echarts实例
            var myChart = echarts.init(document.getElementById('fb1'));

            // 定义一个颜色数组
            const colors = [
                '#FF5733', '#FFBD33', '#FFC300', '#E5FF33', '#33FF57',
                '#33FFC1', '#33A1FF', '#3375FF', '#8B33FF', '#FF33B7'
            ];

            // 将数据转换为适合词云图的格式，并设置颜色和字体大小
            var wordCloudData = res.map(item => {
                return {
                    name: item.name, // 词的名称
                    value: item.value, // 词的值（用于字体大小）
                    itemStyle: {
                        color: colors[Math.floor(Math.random() * colors.length)] // 随机选择颜色
                    },
                    fontSize: Math.random() * (60 - 20) + 20 // 随机字体大小（20到60之间）
                };
            });

            var option = {

                tooltip: {
                    trigger: 'item',
                    formatter: '{b}: {c}' // 显示每个词的名称和对应的值
                },
                series: [{
                    name: '词云',
                    type: 'wordCloud',
                    gridSize: 20,
                    rotationRange: [0, 90], // 允许词汇旋转的角度范围
                    shape: 'circle', // 控制形状
                    emphasis: {
                        focus: 'self',

                    },
                    data: wordCloudData // 词云数据
                }]
            };

            // 使用刚指定的配置项和数据显示图表。
            myChart.setOption(option);

            // 窗口大小变化时，图表自适应
            window.addEventListener("resize", function () {
                myChart.resize();
            });
        });
    }





})



		
		
		


		









