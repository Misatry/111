from django.contrib import admin
from .models import *

# Register your models here.

admin.site.site_header = '动漫数据分析推荐系统管理后台'  # 设置header
admin.site.site_title = '动漫数据分析推荐系统管理后台'  # 设置title
admin.site.index_title = '动漫数据分析推荐系统管理后台'


class UserAdmin(admin.ModelAdmin):
    list_display = ['username', 'email', 'phone']
    list_editable = ['username']  # 使得 username 可编辑
    list_display_links = ['email']  # 指定一个链接字段
    search_fields = ['username']
    list_per_page = 5


admin.site.register(User, UserAdmin)


class AnimeAdmin(admin.ModelAdmin):
    # 定义要在管理后台列表视图中显示的所有字段
    list_display = (
        'name', 'cover', 'type', 'rank', 'episodes',
        'release_date', 'director', 'voice_actors',
        'scriptwriters', 'rating', 'rating_count'
    )
    # 允许根据这些字段进行搜索
    search_fields = ('name', 'director', 'type')
    # 允许根据这些字段进行过滤
    list_filter = ('type', 'director', 'rank')
    list_per_page = 10


# 注册模型和管理类
admin.site.register(Anime, AnimeAdmin)


class CollectAdmin(admin.ModelAdmin):
    list_display = ['user_id', 'cartool_id', 'name', 'cover', 'rating', 'rating_count', 'release_date', 'director',
                    'episodes', 'type', 'scriptwriters', 'voice_actors']
    list_per_page = 10


admin.site.register(Collect, CollectAdmin)