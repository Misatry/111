from django.urls import path
from myhome import views

urlpatterns = [
    path('register/', views.register, name='register'),
    path('login/', views.login, name='login'),
    path('index/', views.index, name='index'),
    path('change_password_view/', views.change_password_view, name='change_password_view'),
    path('user_view/', views.user_view, name='user_view'),
    path('cartool/', views.cartool, name='cartool'),
    path('cartool_detail/<int:id>', views.cartool_detail, name='cartool_detail'),
    path('comment/<int:id>', views.comment, name='myhome_comment'),
    path('collect/<int:music_id>/', views.collect_music, name='collect_music'),
    path('echarts1/', views.echarts1, name='echarts1'),
    path('uncollect/', views.uncollect, name='uncollect'),
    path('echarts2/', views.echarts2, name='echarts2'),
    path('echarts3/', views.echarts3, name='echarts3'),
    path('echarts4/', views.echarts4, name='echarts4'),
    path('data_mining/', views.data_mining, name='data_mining'),
    path('logout/', views.logout, name='logout'),
]
