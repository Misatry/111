import pandas as pd
import pymysql
import os
from django.core.paginator import Paginator, EmptyPage, PageNotAnInteger
from django.http import JsonResponse
from django.shortcuts import render, HttpResponse, redirect, get_object_or_404
import datetime

from django.views.decorators.csrf import csrf_exempt

from Cartool_djangoProject import settings
from .models import *
from django.utils.timezone import now
from django.db.models import Count, Sum, Avg

from django.db.models.functions import Cast, TruncDate, Substr


# Create your views here.

def register(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        if User.objects.filter(username=username).exists():
            return JsonResponse({'error': '用户名已存在'})
        User.objects.create(username=username, password=password)
        return JsonResponse({})
    return render(request, 'auth-register.html')


def login(request):
    if request.method == 'POST':
        username = request.POST.get('username')
        password = request.POST.get('password')
        print(username, password)
        if username == '' or password == '':
            return JsonResponse({'error': '用户名和密码不能为空'})
        user = User.objects.filter(username=username).first()
        if user is not None and user.password == password:
            # 登录成功，保存用户id到session中
            request.session['user_id'] = user.id
            return JsonResponse({'user_id': user.id})
        else:
            return JsonResponse({'error': '用户名或密码不正确'})
    return render(request, 'auth-login.html')


def index(request):
    user_id = request.session.get("user_id")
    user = get_object_or_404(User, id=user_id)
    print('-------------', user.face)
    total_users = User.objects.count()
    total_anime = Anime.objects.count()  # 获取动漫总数
    latest_comments = Comment.objects.order_by('-ctime')[:5]

    # 使用 substring 提取年月日
    user_creation_stats = User.objects.annotate(
        day=Substr('addtime', 1, 10)  # 提取前 10 个字符，即 YYYY-MM-DD
    ).values('day').annotate(
        count=Count('id')
    ).order_by('day')

    # 处理用户注册日期数据
    user_creation_stats = list(user_creation_stats)  # 转换为列表

    user_data = {
        'total_users': total_users,
        'total_anime ': total_anime,
        'user_creation_stats': user_creation_stats,

    }
    print(user_creation_stats)
    context = {
        'user': user,
        'user_data': user_data,
        'latest_comments': latest_comments
    }

    return render(request, 'index.html', context)


def user_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return HttpResponse("未登录", status=401)

    user = get_object_or_404(User, id=user_id)

    if request.method == 'POST':
        user.username = request.POST.get('username')
        user.email = request.POST.get('email')
        user.phone = request.POST.get('phone')
        user.addtime = request.POST.get('addtime') or now()
        user.info = request.POST.get('info')

        avatar = request.FILES.get('avatar')
        if avatar:
            static_path = os.path.join(settings.BASE_DIR, 'static', 'image')
            os.makedirs(static_path, exist_ok=True)
            filename = os.path.join(static_path, avatar.name)

            with open(filename, 'wb+') as destination:
                for chunk in avatar.chunks():
                    destination.write(chunk)

            user.face = 'image/' + avatar.name

        user.save()
        return redirect('user_view')

    else:
        from_page = request.GET.get('fp', 1)
        return render(request, 'user_view.html', {'user': user, 'from_page': from_page})


def change_password_view(request):
    user_id = request.session.get("user_id")
    if not user_id:
        return HttpResponse("未登录", status=401)

    user = get_object_or_404(User, id=user_id)
    error_message = None  # 用于存储错误信息
    success_message = None  # 用于存储成功信息

    if request.method == 'POST':
        current_password = request.POST.get('current_password')
        new_password = request.POST.get('new_password')
        confirm_password = request.POST.get('confirm_password')

        # 校验当前密码是否正确（直接比较明文）
        if current_password != user.password:
            error_message = "当前密码错误"
        # 校验新密码与确认密码是否匹配
        elif new_password != confirm_password:
            error_message = "新密码和确认密码不匹配"
        else:
            user.password = new_password
            user.save()
            success_message = "密码修改成功"  # 设置成功信息
            return render(request, 'change_password.html', {'user': user, 'success_message': success_message})

    return render(request, 'change_password.html', {'user': user, 'error_message': error_message})


def cartool(request):
    user_id = request.session.get('user_id')
    user = get_object_or_404(User, id=user_id)
    # 获取所有动漫条目
    anime_list = Anime.objects.all()

    # 设置每页显示的条数
    items_per_page = 18
    paginator = Paginator(anime_list, items_per_page)

    # 获取当前页码，确保页码是合法的正整数
    page_number = request.GET.get('page', 1)  # 默认第一页
    try:
        page_number = int(page_number)
        if page_number < 1:
            page_number = 1  # 如果页码小于1，重置为1
    except ValueError:
        page_number = 1  # 如果页码不是整数，重置为1

    try:
        page_obj = paginator.get_page(page_number)
    except (PageNotAnInteger, EmptyPage):
        # 如果页码无效或者超出范围，返回最后一页
        page_obj = paginator.page(paginator.num_pages)
    return render(request, 'cartool_list.html', {'page_obj': page_obj, 'user': user})


def cartool_detail(request, id):
    user_id = request.session.get('user_id')
    user = get_object_or_404(User, id=user_id)
    # 获取用户的收藏动漫IDs
    if user_id:
        favorite_items = Collect.objects.filter(user_id=user_id).values_list('cartool_id', flat=True)
    else:
        favorite_items = []

    # 获取动漫信息
    anime_info = get_object_or_404(Anime, id=id)

    # 随机获取一些相关的动漫数据
    random_anime_data = Anime.objects.exclude(id=id).order_by('?')[:12]

    # 获取相关的评论
    comments = Comment.objects.filter(fid=id)
    return render(request, 'car_detail.html', {
        'anime_info': anime_info,
        'commentlist': comments,
        'favorite_items': favorite_items,
        'random_anime_data': random_anime_data,
        'user': user,
    })


@csrf_exempt
def comment(request, id):
    if request.method == 'POST':
        uid = request.session.get('user_id')
        user = User.objects.get(id=uid)
        realname = user.username
        comment_text = request.POST.get("comment", '')

        commentdata = {
            'uid': uid,
            'fid': id,
            'realname': realname,
            'conten': comment_text,
        }

        commentobj = Comment(**commentdata)
        commentobj.save()

        response_data = {
            'status': 'success',
            'realname': realname,
            'comment': comment_text,
            'ctime': commentobj.ctime.strftime('%Y-%m-%d %H:%M:%S')  # 这里不会是 None
        }
        return JsonResponse(response_data)

    return JsonResponse({'status': 'error'}, status=400)


@csrf_exempt  # 如果您使用的是 CSRF 保护，请保留此装饰器
def collect_music(request, music_id):
    if request.method == 'POST':
        user_id = request.session.get('user_id')
        # print('-------------------', music_id)
        if not user_id:
            return JsonResponse({'status': 'error', 'message': '用户未登录'}, status=403)

        # 获取动漫数据
        anime_data = get_object_or_404(Anime, id=music_id)

        # 创建收藏对象
        collect = Collect(
            user_id=user_id,
            cartool_id=anime_data.id,  # 使用对应的动漫 ID
            cover=anime_data.cover,  # 封面
            name=anime_data.name,  # 动漫名称
            type=anime_data.type,  # 动漫类型
            rank=anime_data.rank,  # 动漫排名
            episodes=anime_data.episodes,  # 动漫话数
            release_date=anime_data.release_date,  # 放送时间
            director=anime_data.director,  # 导演
            voice_actors=anime_data.voice_actors,  # 声优
            scriptwriters=anime_data.scriptwriters,  # 脚本
            rating=anime_data.rating,  # 评分
            rating_count=anime_data.rating_count  # 评分人数
        )

        collect.save()

        return JsonResponse({'status': 'success'})

    return JsonResponse({'status': 'error'}, status=400)


@csrf_exempt  # 如果你使用Django的CSRF保护，需要加上这个装饰器
def uncollect(request):
    if request.method == 'POST':
        user_id = request.session.get("user_id")
        anime_id = request.POST.get('anime_id')
        # 删除对应的收藏记录
        Collect.objects.filter(user_id=user_id, cartool_id=anime_id).delete()
        return JsonResponse({'message': '取消收藏成功!'})

    return JsonResponse({'message': '无效请求'}, status=400)


def echarts1(request):
    user_id = request.session.get("user_id")
    user = get_object_or_404(User, id=user_id)
    # 从数据库中获取所有数据
    part1_data = Part1.objects.all()

    # 构建数据列表以适应 ECharts 数据格式
    data = []
    for part in part1_data:
        data.append({'value': part.value, 'name': part.name})

    context = {
        'chart_data': data,  # 将数据传递到模板
        'user': user  # 将数据传递到模板
    }
    return render(request, 'echarts1.html', context)


def echarts2(request):
    user_id = request.session.get("user_id")
    user = get_object_or_404(User, id=user_id)
    # 查询 Part2 的数据
    part2_data = Part2.objects.all().order_by('-value')[:10]
    part2_name = [part.name for part in part2_data]
    part2_value = [part.value for part in part2_data]
    return render(request, 'echarts2.html', {'part2_name': part2_name, 'part2_value': part2_value, 'user': user})


def echarts3(request):
    user_id = request.session.get("user_id")
    user = get_object_or_404(User, id=user_id)
    # 查询 Part3 的数据
    part3_data = Part3.objects.all().order_by('-value')[:10]
    part3_name = [part.name for part in part3_data]
    part3_value = [part.value for part in part3_data]
    return render(request, 'echarts3.html', {'part3_name': part3_name, 'part3_value': part3_value, 'user': user})


def echarts4(request):
    user_id = request.session.get("user_id")
    user = get_object_or_404(User, id=user_id)
    # 从数据库中获取所有数据
    part4_data = Part4.objects.all().order_by('-value')[:10]

    # 构建数据列表以适应 ECharts 数据格式
    data = []
    for part in part4_data:
        data.append({'value': part.value, 'name': part.name})

    context = {
        'user': data,  # user
        'chart_data': data  # 将数据传递到模板
    }
    return render(request, 'echarts4.html', context)


def data_mining(request):
    user_id = request.session.get('user_id')
    recs = Rec.objects.filter(user_id=user_id)

    # 获取所有对应的 car_tool_id
    car_tool_ids = recs.values_list('car_tool_id', flat=True)

    # 根据 car_tool_id 从 Anime 表中查找对应的动漫
    products = Anime.objects.filter(id__in=car_tool_ids)

    # 设置每页显示的条数
    items_per_page = 10
    paginator = Paginator(products, items_per_page)

    # 获取当前页码
    page_number = request.GET.get('page', 1)  # 默认第一页
    page_obj = paginator.get_page(page_number)  # 获取当前页的对象
    # 获取用户的收藏商品IDs
    if user_id:
        favorite_items = Collect.objects.filter(user_id=user_id).values_list('cartool_id', flat=True)
    else:
        favorite_items = []
    return render(request, 'data_mining.html', {'page_obj': page_obj, 'favorite_items': favorite_items})


def logout(request):
    # 清除session的所有内容
    request.session.flush()
    # 重定向到登录页面
    return redirect('login')
