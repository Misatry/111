from django.db import models
from datetime import datetime

# Create your models here.
class User(models.Model):
    """ 用户表 """
    username = models.CharField(max_length=255, verbose_name='用户名')
    password = models.CharField(max_length=255, verbose_name='密码')
    email = models.EmailField(unique=True, null=True, max_length=100)
    # 手机号
    phone = models.CharField(unique=True, null=True, max_length=11)
    # 个性简介
    info = models.TextField(blank=True, null=True)
    # 头像
    face = models.CharField(max_length=255, unique=True, blank=True, null=True)
    # 注册时间
    addtime = models.DateTimeField(default=datetime.now, db_index=True)

    class Meta:
        # 表名
        # managed = False
        db_table = 'users'
        verbose_name = '用户'


class Comment(models.Model):
    uid = models.IntegerField()
    fid = models.IntegerField()
    realname = models.CharField(max_length=11)
    conten = models.TextField()
    ctime = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = 'comment'  # 指定数据库表名
        verbose_name = '评论'
        verbose_name_plural = '评论管理'


class Anime(models.Model):
    cover = models.CharField(max_length=255, blank=True, null=True, verbose_name='封面')
    name = models.CharField(max_length=255, unique=True, verbose_name='名称')  # 假设名称是唯一的
    type = models.CharField(max_length=50, blank=True, null=True, verbose_name='类型')
    rank = models.IntegerField(blank=True, null=True, verbose_name='排名')
    episodes = models.IntegerField(blank=True, null=True, verbose_name='话数')
    release_date = models.CharField(max_length=100, blank=True, null=True,
                                    verbose_name='放送时间')  # 这里用 CharField，因为原表设计为 varchar
    director = models.CharField(max_length=255, blank=True, null=True, verbose_name='导演')
    voice_actors = models.TextField(blank=True, null=True, verbose_name='声优')
    scriptwriters = models.TextField(blank=True, null=True, verbose_name='脚本')
    rating = models.DecimalField(max_digits=3, decimal_places=1, blank=True, null=True, verbose_name='评分')
    rating_count = models.IntegerField(blank=True, null=True, verbose_name='评分人数')

    class Meta:
        db_table = 'anime'  # 指定数据库表名


class Collect(models.Model):
    """ 用户收藏的动漫信息 """
    user_id = models.IntegerField(null=True, blank=True, verbose_name='用户id')
    cartool_id = models.IntegerField(null=True, blank=True, verbose_name='动漫id')
    cover = models.CharField(max_length=255, null=True, blank=True, verbose_name='封面')
    name = models.CharField(max_length=255, null=True, blank=True, verbose_name='名称')
    type = models.CharField(max_length=50, null=True, blank=True, verbose_name='类型')
    rank = models.IntegerField(null=True, blank=True, verbose_name='排名')
    episodes = models.IntegerField(null=True, blank=True, verbose_name='话数')
    release_date = models.CharField(max_length=100, null=True, blank=True, verbose_name='放送时间')
    director = models.CharField(max_length=255, null=True, blank=True, verbose_name='导演')
    voice_actors = models.TextField(null=True, blank=True, verbose_name='声优')
    scriptwriters = models.TextField(null=True, blank=True, verbose_name='脚本')
    rating = models.DecimalField(max_digits=3, decimal_places=1, null=True, blank=True, verbose_name='评分')
    rating_count = models.IntegerField(null=True, blank=True, verbose_name='评分人数')

    class Meta:
        db_table = 'collect'  # 指定数据库表名


class Part1(models.Model):
    """ 部件表 """
    id = models.AutoField(primary_key=True)  # 自动递增的主键
    name = models.CharField(max_length=255, blank=True, null=True)  # 部件名称
    value = models.BigIntegerField(blank=True, null=True)  # 部件值

    class Meta:
        db_table = 'part1'  # 指定数据库表名


class Part2(models.Model):
    """ 部件表 """
    id = models.AutoField(primary_key=True)  # 自动递增的主键
    name = models.CharField(max_length=255, blank=True, null=True)  # 部件名称
    value = models.BigIntegerField(blank=True, null=True)  # 部件值

    class Meta:
        db_table = 'part2'  # 指定数据库表名


class Part3(models.Model):
    """ 部件表 """
    id = models.AutoField(primary_key=True)  # 自动递增的主键
    name = models.CharField(max_length=255, blank=True, null=True)  # 部件名称
    value = models.BigIntegerField(blank=True, null=True)  # 部件值

    class Meta:
        db_table = 'part3'  # 指定数据库表名


class Part4(models.Model):
    """ 部件表 """
    id = models.AutoField(primary_key=True)  # 自动递增的主键
    name = models.CharField(max_length=255, blank=True, null=True)  # 部件名称
    value = models.BigIntegerField(blank=True, null=True)  # 部件值

    class Meta:
        db_table = 'part4'  # 指定数据库表名


class Rec(models.Model):
    """ 推荐表 """
    id = models.AutoField(primary_key=True)  # 自动递增的主键
    user_id = models.IntegerField(blank=True, null=True)  # 用户ID
    car_tool_id = models.IntegerField(blank=True, null=True)  # 车工具ID
    score = models.FloatField(blank=True, null=True)  # 评分

    class Meta:
        db_table = 'rec'  # 指定数据库表名
        verbose_name = '推荐'
